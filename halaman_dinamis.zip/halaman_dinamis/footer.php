</div>
  <!-- konten -->
  <footer>
    <p>Copyright © 2021 | SMKN 7 BALEENDAH</p>
  </footer>
  
</body>
</html>
