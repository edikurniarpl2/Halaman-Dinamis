<h3>Profile Sekolah</h3>
<h5><p>Nama : SMK NEGERI 7 BALEENDAH</p>

<p>Tahun Didirikan : 2005</p>

<p>Kepala Sekolah : AGUS MUSLIHIN, S.PD., MT.</p>

<p>Status : Sekolah Negeri</p>

<p>Jumlah Guru & TU : 98</p>

<p>Jumlah Kelas : 32</p>

<p>Rombongan Belajar : 42</p>

<p>Alamat : Jalan Siliwangi KM.15, Manggahang, Baleendah, Manggahang, Kec. Baleendah, Bandung, Jawa Barat 40375</p></h5>