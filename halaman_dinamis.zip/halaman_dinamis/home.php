<h3>SMK Negeri 7 Baleendah berdiri pada tahun 2005 tepatnya pada Kamis 29 Desember 2005.</h3>
	<center><img src="LOGO.jpg"></center>