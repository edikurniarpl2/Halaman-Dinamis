<h3>Kontak Kami</h3>
<p>Jika kamu ingin mengajukan pertanyaan seputar SMKN 7 Baleendah bisa dengan cara mengisi form kontak kami dengan nama dan email asli kamu. Nanti balasannya akan terkirim ke email kamu</p>

<h4>SMKN 7 Baleendah</h4>
<table border="1" cellpadding="4">
<tr>
	<td>NPSN</td>	
	<td>20229784</td>
</tr>
<tr>
	<td>Nomer Telpon</td>	
	<td>(022) 87799654</td>
</tr>
<tr>
	<td>Nomer Faks</td>	
	<td>-</td>
</tr>
<tr>
	<td>Email</td>	
	<td>smkn7.baleendah@yahoo.co.id</td>
</tr>
<tr>
	<td>Jenjang</td>	
	<td>SMK</td>
</tr>
</table>